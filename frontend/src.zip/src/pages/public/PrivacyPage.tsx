import ModernPublicLayout from '../../components/layout/ModernPublicLayout';
import SEO from '../../components/common/SEO';

const sections = [
  {
    title: 'Thong tin thu thap',
    content: 'Chung toi thu thap thong tin ban cung cap khi dang ky, lien he, tra cuu hoac su dung cac dich vu tren website de xu ly ho so, ho tro va cai thien chat luong dich vu.'
  },
  {
    title: 'Muc dich su dung',
    content: 'Du lieu duoc su dung de xac nhan danh tinh, tu van khoa hoc, thong bao lich hoc lich thi, xu ly ho so va dam bao van hanh an toan cua he thong.'
  },
  {
    title: 'Bao mat va luu tru',
    content: 'Chung toi ap dung cac bien phap ky thuat va quy trinh noi bo de han che truy cap trai phep, mat du lieu hoac su dung sai muc dich doi voi thong tin ca nhan.'
  },
  {
    title: 'Lien he',
    content: 'Neu can yeu cau chinh sua, cap nhat hoac xoa du lieu, vui long lien he Van Trang Education qua hotline 096 244 5963 hoac email info@vantrangedu.edu.vn.'
  }
];

export default function PrivacyPage() {
  return (
    <ModernPublicLayout>
      <SEO
        title="Chinh sach bao mat"
        description="Thong tin ve cach Van Trang Education thu thap, su dung va bao ve du lieu ca nhan tren website."
        url="/privacy"
        structuredData={{
          '@type': 'WebPage',
          name: 'Chinh sach bao mat',
          description: 'Chinh sach bao mat du lieu cua Van Trang Education.',
          url: 'https://vantrangedu.com/privacy'
        }}
      />

      <div className="min-h-screen bg-slate-50 py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="mb-10">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-600 mb-3">Van Trang Education</p>
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4">Chinh Sach Bao Mat</h1>
            <p className="text-slate-600 text-lg leading-relaxed">
              Tai lieu nay mo ta cach chung toi xu ly thong tin ca nhan khi ban su dung website va cac bieu mau cong khai cua Van Trang Education.
            </p>
          </div>

          <div className="space-y-6">
            {sections.map((section) => (
              <section key={section.title} className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
                <h2 className="text-2xl font-bold text-slate-900 mb-3">{section.title}</h2>
                <p className="text-slate-600 leading-7">{section.content}</p>
              </section>
            ))}
          </div>
        </div>
      </div>
    </ModernPublicLayout>
  );
}
